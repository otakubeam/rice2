// Package pushrules contains utilities to parse push notification rules.
package pushrules
