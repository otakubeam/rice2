// Package format contains utilities for working with Matrix HTML, specifically
// methods to parse Markdown into HTML and to parse Matrix HTML into text or markdown.
//
// https://matrix.org/docs/spec/client_server/r0.6.0#m-room-message-msgtypes
package format
