package mautrix

const Version = "v0.8.0"
