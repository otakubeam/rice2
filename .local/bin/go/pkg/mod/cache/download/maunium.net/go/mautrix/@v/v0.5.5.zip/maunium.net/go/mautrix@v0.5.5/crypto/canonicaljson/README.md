# canonicaljson
This is a Go package to produce Matrix [Canonical JSON](https://matrix.org/docs/spec/appendices#canonical-json).
It is essentially just [json.go](https://github.com/matrix-org/gomatrixserverlib/blob/master/json.go)
from gomatrixserverlib without all the other files that are completely useless for non-server use cases.
