# Go olm bindings
Based on [Dhole/go-olm](https://github.com/Dhole/go-olm)
