package mautrix

const Version = "v0.5.5"
