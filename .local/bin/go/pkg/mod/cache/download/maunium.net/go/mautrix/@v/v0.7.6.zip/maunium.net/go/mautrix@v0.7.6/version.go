package mautrix

const Version = "v0.7.6"
